//@<COPYRIGHT>@
//==================================================
//Copyright $2026.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension C9testValidateBool
 *
 */
#include <C9testlib/C9testValidateBool.hxx>
#include <epm/epm.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/aom_prop.h>
#include <tccore/WorkspaceObject.h>
#include <sa/tcfile.h>
#include <sa/sa.h>
#include <sa/sa_errors.h>
#include <sa/role.h>
#include <sa/group.h>
#include <sa/groupmember.h>
#include <sa/user.h>
#include <ae/ae.h>
#include <fclasses/tc_date.h>
#include <fclasses/tc_string.h>

int ValidateBool(EPM_action_message_t msg);

int C9testValidateBool( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
	EPM_register_action_handler("Validate Bool", "Workflow assigned to different roles based on boolean value", ValidateBool);
	return 0;

}

int ValidateBool(EPM_action_message_t msg)
{
	int ifail = ITK_ok;

	    tag_t rootTask = NULLTAG;
	    tag_t *targets = NULL;
	    tag_t *groupMembers = NULL;
	    int targetCount = 0;
	    int groupCount = 0;

	    logical boolValue = FALSE;

	    tag_t groupTag = NULLTAG;
	    tag_t roleTag = NULLTAG;


	    ifail = EPM_ask_root_task(msg.task, &rootTask);
	    if (ifail != ITK_ok) return ifail;


	    ifail = EPM_ask_attachments(rootTask,
	                                EPM_target_attachment,
	                                &targetCount,
	                                &targets);
	    if (ifail != ITK_ok || targetCount == 0)
	        return ifail;


	    ifail = AOM_ask_value_logical(targets[0],
	                                  "c9Boolean_Property",
	                                  &boolValue);
	    if (ifail != ITK_ok) return ifail;


	    ifail = SA_find_group("Engineering", &groupTag);
	    if (ifail != ITK_ok) return ifail;


	    if (boolValue == FALSE)
	        ifail = SA_find_role2("Designer", &roleTag);
	    else
	        ifail = SA_find_role2("Checker", &roleTag);

	    if (ifail != ITK_ok) return ifail;

	    ifail = SA_find_groupmember_by_role(roleTag,groupTag,&groupCount,&groupMembers);

	    ifail = EPM_add_reviewers_on_task(rootTask, TRUE, 1,
	                    groupMembers);
	    if (ifail != ITK_ok) return ifail;


	    if (targets) MEM_free(targets);
	    if (groupMembers) MEM_free(groupMembers);

	    return ifail;
}
