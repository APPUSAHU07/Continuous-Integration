//@<COPYRIGHT>@
//==================================================
//Copyright $2026.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension C9testcreationdate
 *
 */
#include <C9testlib/C9testcreationdate.hxx>
#include <epm/epm.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/WorkspaceObject.h>
#include <sa/tcfile.h>
#include <fclasses/tc_date.h>
#include <fclasses/tc_string.h>

#define ERROR_INVALID_DATE  919001

EPM_decision_t ValidateCreationDate(EPM_rule_message_t msg);

int C9testcreationdate( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
	TC_write_syslog("Entering C9testcreationdate function");

	EPM_register_rule_handler("Validate Date", "Validate the creation date of the object",ValidateCreationDate);

	TC_write_syslog("Exiting C9testcreationdate function");
 return 0;

}

EPM_decision_t ValidateCreationDate(EPM_rule_message_t msg){

		TC_write_syslog("Entering RuleHandler function");

			int ifail = ITK_ok;
			EPM_decision_t decision = EPM_go;
		    int target_count = 0;
		    tag_t *targets = NULL;

		    date_t creation_date;
		    char* date_string = "";

		    /* Get root task */
		    tag_t root_task = NULLTAG;
		    ifail = EPM_ask_root_task(msg.task, &root_task);
		    if (ifail != ITK_ok) return EPM_nogo;

		    /* Get target attachments */
		    ifail = EPM_ask_attachments(root_task, EPM_target_attachment,
		                                 &target_count, &targets);
		    if (ifail != ITK_ok) return EPM_nogo;


		        for (int i = 0; i < target_count; i++)
		        {
		            char *type_name = NULL;

		            WSOM_ask_object_type2(targets[i], &type_name);

		            if (tc_strcmp(type_name, "ItemRevision") == 0)
		            {
		                AOM_ask_value_date(targets[i], "creation_date", &creation_date);

		                DATE_date_to_string(creation_date,"%d-%b-%Y %H:%M:%S", &date_string);

		                if (tc_strstr(date_string, "Jan-2026") == NULL)
		                {
		                    EMH_store_error_s1(
		                        EMH_severity_error,
		                        ERROR_INVALID_DATE,
		                        "The object was not created within January 2026."
		                    );

		                    decision = EPM_nogo;
		                    MEM_free(type_name);
		                    break;
		                }
		            }

		            MEM_free(type_name);
		        }

		    if (targets) MEM_free(targets);

		    TC_write_syslog("Exiting RuleHandler function");
		    return decision;
}
