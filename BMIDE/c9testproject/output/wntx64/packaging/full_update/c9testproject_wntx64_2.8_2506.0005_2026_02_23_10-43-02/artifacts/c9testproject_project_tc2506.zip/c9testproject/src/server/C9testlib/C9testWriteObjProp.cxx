//@<COPYRIGHT>@
//==================================================
//Copyright $2026.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension C9testWriteObjProp
 *
 */
#include <C9testlib/C9testWriteObjProp.hxx>

int C9testWriteObjProp( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
 
 return 0;

}