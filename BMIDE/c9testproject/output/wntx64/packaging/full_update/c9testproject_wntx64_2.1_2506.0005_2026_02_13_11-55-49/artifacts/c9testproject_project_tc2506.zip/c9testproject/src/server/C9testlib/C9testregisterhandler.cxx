//@<COPYRIGHT>@
//==================================================
//Copyright $2026.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension C9testregisterhandler
 *
 */
#include <C9testlib/C9testregisterhandler.hxx>
#include <epm/epm.h>

EPM_decision_t RuleHandlerFunc(EPM_rule_message_t msg);

int C9testregisterhandler( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
	TC_write_syslog("Entering C9testregisterhandler function");
 
	EPM_register_rule_handler("MyRuleHandler", "Custom Rule Handler", RuleHandlerFunc);

	TC_write_syslog("Exiting C9testregisterhandler function");
	return 0;
}

EPM_decision_t RuleHandlerFunc(EPM_rule_message_t msg)
{
	TC_write_syslog("Entering RuleHandlerFunc function");

	EPM_decision_t status = EPM_go;

	// My functionality

	tag_t tTask = msg.task;

		status = EPM_nogo;


	TC_write_syslog("Exiting RuleHandlerFunc function %d", tTask);
	return status;
}
