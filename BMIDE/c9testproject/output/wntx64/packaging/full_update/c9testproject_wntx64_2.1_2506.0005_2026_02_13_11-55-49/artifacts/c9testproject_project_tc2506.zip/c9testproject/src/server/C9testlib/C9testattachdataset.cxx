//@<COPYRIGHT>@
//==================================================
//Copyright $2026.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension C9testattachdataset
 *
 */
#include <C9testlib/C9testattachdataset.hxx>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/method.h>
#include <tc/emh.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>
#include <ae/ae.h>


int C9testattachdataset(METHOD_message_t /*msg*/, va_list args)
{
		TC_write_syslog("Entering C9testattachdataset");
		va_list largs;
	    va_copy(largs, args);

	    tag_t item_tag = va_arg(largs, tag_t);
	    va_end(largs);

	    tag_t item_rev = NULLTAG;
	    ITEM_ask_latest_rev(item_tag, &item_rev);


	    tag_t datasetType = NULLTAG;
	    tag_t createInput = NULLTAG;
	    tag_t newDataset = NULLTAG;
	    tag_t relationType = NULLTAG;
	    tag_t relation = NULLTAG;

	    TCTYPE_find_type("MSWord", "", &datasetType);
	    TCTYPE_construct_create_input(datasetType, &createInput);

	    AOM_set_value_string(createInput, "object_name", "Word Spec");
	    AOM_set_value_string(createInput, "object_desc", "Automatically created Word document");

	    TCTYPE_create_object(createInput, &newDataset);
	    AOM_save_without_extensions(newDataset);
	    AOM_unlock(newDataset);



	    GRM_find_relation_type("IMAN_specification", &relationType);


	    GRM_create_relation(item_rev, newDataset, relationType, NULLTAG, &relation);
	    GRM_save_relation(relation);


	    return ITK_ok;

}
